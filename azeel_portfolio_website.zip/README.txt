# Azeel — Personal Portfolio Website

## Preview locally
1. Download and unzip `azeel_portfolio_website.zip`.
2. Open the `index.html` file in a browser.

## Publish free with GitHub Pages
1. Sign in to GitHub or create an account at https://github.com/.
2. Create a new **public** repository, for example `azeel-portfolio`.
3. Upload `index.html` to the repository's root (top level).
4. Open the repository's **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select the `main` branch and `/ (root)`, then save.
7. Wait a few minutes. GitHub will show the published site URL in the Pages section. It will usually look like `https://YOUR-USERNAME.github.io/azeel-portfolio/`.

## Before using it for job applications
- Confirm the name “Azeel” is how you want to appear publicly.
- Add a professional contact email if you want employers to contact you directly.
- Add only accurate education details, dates, grades, and certificates.
- This is a static website; it does not collect or send any personal information.
- If you prefer not to make a public GitHub repository, use a static-hosting service with private account controls and follow its current publishing instructions.

## Edit the content
Open `index.html` in a text editor and search for the wording you want to change. Save it and upload the updated file to your hosting repository.
